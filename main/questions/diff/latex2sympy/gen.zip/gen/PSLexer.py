# Generated from PS.g4 by ANTLR 4.5.1
# encoding: utf-8
from __future__ import print_function
from antlr4 import *
from io import StringIO


def serializedATN():
    with StringIO() as buf:
        buf.write(u"\3\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\2")
        buf.write(u"9\u01da\b\1\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4")
        buf.write(u"\7\t\7\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r")
        buf.write(u"\t\r\4\16\t\16\4\17\t\17\4\20\t\20\4\21\t\21\4\22\t\22")
        buf.write(u"\4\23\t\23\4\24\t\24\4\25\t\25\4\26\t\26\4\27\t\27\4")
        buf.write(u"\30\t\30\4\31\t\31\4\32\t\32\4\33\t\33\4\34\t\34\4\35")
        buf.write(u"\t\35\4\36\t\36\4\37\t\37\4 \t \4!\t!\4\"\t\"\4#\t#\4")
        buf.write(u"$\t$\4%\t%\4&\t&\4\'\t\'\4(\t(\4)\t)\4*\t*\4+\t+\4,\t")
        buf.write(u",\4-\t-\4.\t.\4/\t/\4\60\t\60\4\61\t\61\4\62\t\62\4\63")
        buf.write(u"\t\63\4\64\t\64\4\65\t\65\4\66\t\66\4\67\t\67\48\t8\4")
        buf.write(u"9\t9\4:\t:\3\2\3\2\3\3\6\3y\n\3\r\3\16\3z\3\3\3\3\3\4")
        buf.write(u"\3\4\3\5\3\5\3\6\3\6\3\7\3\7\3\b\3\b\3\t\3\t\3\n\3\n")
        buf.write(u"\3\13\3\13\3\f\3\f\3\r\3\r\3\16\3\16\3\17\3\17\3\17\3")
        buf.write(u"\17\3\17\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20")
        buf.write(u"\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3")
        buf.write(u"\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20")
        buf.write(u"\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3")
        buf.write(u"\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20\3\20")
        buf.write(u"\3\20\3\20\3\20\3\20\5\20\u00d1\n\20\3\21\3\21\3\21\3")
        buf.write(u"\21\3\21\3\22\3\22\3\22\3\22\3\22\3\23\3\23\3\23\3\23")
        buf.write(u"\3\23\3\23\3\24\3\24\3\24\3\24\3\24\3\25\3\25\3\25\3")
        buf.write(u"\25\3\26\3\26\3\26\3\26\3\26\3\27\3\27\3\27\3\27\3\27")
        buf.write(u"\3\30\3\30\3\30\3\30\3\30\3\31\3\31\3\31\3\31\3\31\3")
        buf.write(u"\32\3\32\3\32\3\32\3\32\3\33\3\33\3\33\3\33\3\33\3\34")
        buf.write(u"\3\34\3\34\3\34\3\34\3\34\3\34\3\34\3\35\3\35\3\35\3")
        buf.write(u"\35\3\35\3\35\3\35\3\35\3\36\3\36\3\36\3\36\3\36\3\36")
        buf.write(u"\3\36\3\36\3\37\3\37\3\37\3\37\3\37\3\37\3\37\3\37\3")
        buf.write(u" \3 \3 \3 \3 \3 \3 \3 \3!\3!\3!\3!\3!\3!\3!\3!\3\"\3")
        buf.write(u"\"\3\"\3\"\3\"\3\"\3#\3#\3#\3#\3#\3#\3$\3$\3$\3$\3$\3")
        buf.write(u"$\3%\3%\3%\3%\3%\3%\3%\3%\3&\3&\3&\3&\3&\3&\3&\3&\3\'")
        buf.write(u"\3\'\3\'\3\'\3\'\3\'\3\'\3\'\3(\3(\3(\3(\3(\3(\3)\3)")
        buf.write(u"\3)\3)\3)\3)\3)\3*\3*\3*\3*\3*\3*\3+\3+\3+\3+\3+\3,\3")
        buf.write(u",\3,\3,\3,\3,\3-\3-\3.\3.\3/\3/\3\60\3\60\7\60\u018a")
        buf.write(u"\n\60\f\60\16\60\u018d\13\60\3\60\3\60\3\60\6\60\u0192")
        buf.write(u"\n\60\r\60\16\60\u0193\5\60\u0196\n\60\3\61\3\61\3\62")
        buf.write(u"\3\62\3\63\6\63\u019d\n\63\r\63\16\63\u019e\3\63\3\63")
        buf.write(u"\3\63\3\63\3\63\7\63\u01a6\n\63\f\63\16\63\u01a9\13\63")
        buf.write(u"\3\63\7\63\u01ac\n\63\f\63\16\63\u01af\13\63\3\63\3\63")
        buf.write(u"\3\63\3\63\3\63\7\63\u01b6\n\63\f\63\16\63\u01b9\13\63")
        buf.write(u"\3\63\3\63\6\63\u01bd\n\63\r\63\16\63\u01be\5\63\u01c1")
        buf.write(u"\n\63\3\64\3\64\3\65\3\65\3\66\3\66\3\66\3\66\3\66\3")
        buf.write(u"\67\3\67\38\38\38\38\38\39\39\3:\3:\6:\u01d7\n:\r:\16")
        buf.write(u":\u01d8\3\u018b\2;\3\3\5\4\7\5\t\6\13\7\r\b\17\t\21\n")
        buf.write(u"\23\13\25\f\27\r\31\16\33\17\35\20\37\21!\22#\23%\24")
        buf.write(u"\'\25)\26+\27-\30/\31\61\32\63\33\65\34\67\359\36;\37")
        buf.write(u"= ?!A\"C#E$G%I&K\'M(O)Q*S+U,W-Y.[/]\2_\60a\61c\2e\62")
        buf.write(u"g\63i\64k\65m\66o\67q8s9\3\2\5\5\2\13\f\17\17\"\"\4\2")
        buf.write(u"C\\c|\3\2\62;\u01e6\2\3\3\2\2\2\2\5\3\2\2\2\2\7\3\2\2")
        buf.write(u"\2\2\t\3\2\2\2\2\13\3\2\2\2\2\r\3\2\2\2\2\17\3\2\2\2")
        buf.write(u"\2\21\3\2\2\2\2\23\3\2\2\2\2\25\3\2\2\2\2\27\3\2\2\2")
        buf.write(u"\2\31\3\2\2\2\2\33\3\2\2\2\2\35\3\2\2\2\2\37\3\2\2\2")
        buf.write(u"\2!\3\2\2\2\2#\3\2\2\2\2%\3\2\2\2\2\'\3\2\2\2\2)\3\2")
        buf.write(u"\2\2\2+\3\2\2\2\2-\3\2\2\2\2/\3\2\2\2\2\61\3\2\2\2\2")
        buf.write(u"\63\3\2\2\2\2\65\3\2\2\2\2\67\3\2\2\2\29\3\2\2\2\2;\3")
        buf.write(u"\2\2\2\2=\3\2\2\2\2?\3\2\2\2\2A\3\2\2\2\2C\3\2\2\2\2")
        buf.write(u"E\3\2\2\2\2G\3\2\2\2\2I\3\2\2\2\2K\3\2\2\2\2M\3\2\2\2")
        buf.write(u"\2O\3\2\2\2\2Q\3\2\2\2\2S\3\2\2\2\2U\3\2\2\2\2W\3\2\2")
        buf.write(u"\2\2Y\3\2\2\2\2[\3\2\2\2\2_\3\2\2\2\2a\3\2\2\2\2e\3\2")
        buf.write(u"\2\2\2g\3\2\2\2\2i\3\2\2\2\2k\3\2\2\2\2m\3\2\2\2\2o\3")
        buf.write(u"\2\2\2\2q\3\2\2\2\2s\3\2\2\2\3u\3\2\2\2\5x\3\2\2\2\7")
        buf.write(u"~\3\2\2\2\t\u0080\3\2\2\2\13\u0082\3\2\2\2\r\u0084\3")
        buf.write(u"\2\2\2\17\u0086\3\2\2\2\21\u0088\3\2\2\2\23\u008a\3\2")
        buf.write(u"\2\2\25\u008c\3\2\2\2\27\u008e\3\2\2\2\31\u0090\3\2\2")
        buf.write(u"\2\33\u0092\3\2\2\2\35\u0094\3\2\2\2\37\u00d0\3\2\2\2")
        buf.write(u"!\u00d2\3\2\2\2#\u00d7\3\2\2\2%\u00dc\3\2\2\2\'\u00e2")
        buf.write(u"\3\2\2\2)\u00e7\3\2\2\2+\u00eb\3\2\2\2-\u00f0\3\2\2\2")
        buf.write(u"/\u00f5\3\2\2\2\61\u00fa\3\2\2\2\63\u00ff\3\2\2\2\65")
        buf.write(u"\u0104\3\2\2\2\67\u0109\3\2\2\29\u0111\3\2\2\2;\u0119")
        buf.write(u"\3\2\2\2=\u0121\3\2\2\2?\u0129\3\2\2\2A\u0131\3\2\2\2")
        buf.write(u"C\u0139\3\2\2\2E\u013f\3\2\2\2G\u0145\3\2\2\2I\u014b")
        buf.write(u"\3\2\2\2K\u0153\3\2\2\2M\u015b\3\2\2\2O\u0163\3\2\2\2")
        buf.write(u"Q\u0169\3\2\2\2S\u0170\3\2\2\2U\u0176\3\2\2\2W\u017b")
        buf.write(u"\3\2\2\2Y\u0181\3\2\2\2[\u0183\3\2\2\2]\u0185\3\2\2\2")
        buf.write(u"_\u0187\3\2\2\2a\u0197\3\2\2\2c\u0199\3\2\2\2e\u01c0")
        buf.write(u"\3\2\2\2g\u01c2\3\2\2\2i\u01c4\3\2\2\2k\u01c6\3\2\2\2")
        buf.write(u"m\u01cb\3\2\2\2o\u01cd\3\2\2\2q\u01d2\3\2\2\2s\u01d4")
        buf.write(u"\3\2\2\2uv\7.\2\2v\4\3\2\2\2wy\t\2\2\2xw\3\2\2\2yz\3")
        buf.write(u"\2\2\2zx\3\2\2\2z{\3\2\2\2{|\3\2\2\2|}\b\3\2\2}\6\3\2")
        buf.write(u"\2\2~\177\7-\2\2\177\b\3\2\2\2\u0080\u0081\7/\2\2\u0081")
        buf.write(u"\n\3\2\2\2\u0082\u0083\7,\2\2\u0083\f\3\2\2\2\u0084\u0085")
        buf.write(u"\7\61\2\2\u0085\16\3\2\2\2\u0086\u0087\7*\2\2\u0087\20")
        buf.write(u"\3\2\2\2\u0088\u0089\7+\2\2\u0089\22\3\2\2\2\u008a\u008b")
        buf.write(u"\7}\2\2\u008b\24\3\2\2\2\u008c\u008d\7\177\2\2\u008d")
        buf.write(u"\26\3\2\2\2\u008e\u008f\7]\2\2\u008f\30\3\2\2\2\u0090")
        buf.write(u"\u0091\7_\2\2\u0091\32\3\2\2\2\u0092\u0093\7~\2\2\u0093")
        buf.write(u"\34\3\2\2\2\u0094\u0095\7^\2\2\u0095\u0096\7n\2\2\u0096")
        buf.write(u"\u0097\7k\2\2\u0097\u0098\7o\2\2\u0098\36\3\2\2\2\u0099")
        buf.write(u"\u009a\7^\2\2\u009a\u009b\7v\2\2\u009b\u00d1\7q\2\2\u009c")
        buf.write(u"\u009d\7^\2\2\u009d\u009e\7t\2\2\u009e\u009f\7k\2\2\u009f")
        buf.write(u"\u00a0\7i\2\2\u00a0\u00a1\7j\2\2\u00a1\u00a2\7v\2\2\u00a2")
        buf.write(u"\u00a3\7c\2\2\u00a3\u00a4\7t\2\2\u00a4\u00a5\7t\2\2\u00a5")
        buf.write(u"\u00a6\7q\2\2\u00a6\u00d1\7y\2\2\u00a7\u00a8\7^\2\2\u00a8")
        buf.write(u"\u00a9\7T\2\2\u00a9\u00aa\7k\2\2\u00aa\u00ab\7i\2\2\u00ab")
        buf.write(u"\u00ac\7j\2\2\u00ac\u00ad\7v\2\2\u00ad\u00ae\7c\2\2\u00ae")
        buf.write(u"\u00af\7t\2\2\u00af\u00b0\7t\2\2\u00b0\u00b1\7q\2\2\u00b1")
        buf.write(u"\u00d1\7y\2\2\u00b2\u00b3\7^\2\2\u00b3\u00b4\7n\2\2\u00b4")
        buf.write(u"\u00b5\7q\2\2\u00b5\u00b6\7p\2\2\u00b6\u00b7\7i\2\2\u00b7")
        buf.write(u"\u00b8\7t\2\2\u00b8\u00b9\7k\2\2\u00b9\u00ba\7i\2\2\u00ba")
        buf.write(u"\u00bb\7j\2\2\u00bb\u00bc\7v\2\2\u00bc\u00bd\7c\2\2\u00bd")
        buf.write(u"\u00be\7t\2\2\u00be\u00bf\7t\2\2\u00bf\u00c0\7q\2\2\u00c0")
        buf.write(u"\u00d1\7y\2\2\u00c1\u00c2\7^\2\2\u00c2\u00c3\7N\2\2\u00c3")
        buf.write(u"\u00c4\7q\2\2\u00c4\u00c5\7p\2\2\u00c5\u00c6\7i\2\2\u00c6")
        buf.write(u"\u00c7\7t\2\2\u00c7\u00c8\7k\2\2\u00c8\u00c9\7i\2\2\u00c9")
        buf.write(u"\u00ca\7j\2\2\u00ca\u00cb\7v\2\2\u00cb\u00cc\7c\2\2\u00cc")
        buf.write(u"\u00cd\7t\2\2\u00cd\u00ce\7t\2\2\u00ce\u00cf\7q\2\2\u00cf")
        buf.write(u"\u00d1\7y\2\2\u00d0\u0099\3\2\2\2\u00d0\u009c\3\2\2\2")
        buf.write(u"\u00d0\u00a7\3\2\2\2\u00d0\u00b2\3\2\2\2\u00d0\u00c1")
        buf.write(u"\3\2\2\2\u00d1 \3\2\2\2\u00d2\u00d3\7^\2\2\u00d3\u00d4")
        buf.write(u"\7k\2\2\u00d4\u00d5\7p\2\2\u00d5\u00d6\7v\2\2\u00d6\"")
        buf.write(u"\3\2\2\2\u00d7\u00d8\7^\2\2\u00d8\u00d9\7u\2\2\u00d9")
        buf.write(u"\u00da\7w\2\2\u00da\u00db\7o\2\2\u00db$\3\2\2\2\u00dc")
        buf.write(u"\u00dd\7^\2\2\u00dd\u00de\7r\2\2\u00de\u00df\7t\2\2\u00df")
        buf.write(u"\u00e0\7q\2\2\u00e0\u00e1\7f\2\2\u00e1&\3\2\2\2\u00e2")
        buf.write(u"\u00e3\7^\2\2\u00e3\u00e4\7n\2\2\u00e4\u00e5\7q\2\2\u00e5")
        buf.write(u"\u00e6\7i\2\2\u00e6(\3\2\2\2\u00e7\u00e8\7^\2\2\u00e8")
        buf.write(u"\u00e9\7n\2\2\u00e9\u00ea\7p\2\2\u00ea*\3\2\2\2\u00eb")
        buf.write(u"\u00ec\7^\2\2\u00ec\u00ed\7u\2\2\u00ed\u00ee\7k\2\2\u00ee")
        buf.write(u"\u00ef\7p\2\2\u00ef,\3\2\2\2\u00f0\u00f1\7^\2\2\u00f1")
        buf.write(u"\u00f2\7e\2\2\u00f2\u00f3\7q\2\2\u00f3\u00f4\7u\2\2\u00f4")
        buf.write(u".\3\2\2\2\u00f5\u00f6\7^\2\2\u00f6\u00f7\7v\2\2\u00f7")
        buf.write(u"\u00f8\7c\2\2\u00f8\u00f9\7p\2\2\u00f9\60\3\2\2\2\u00fa")
        buf.write(u"\u00fb\7^\2\2\u00fb\u00fc\7e\2\2\u00fc\u00fd\7u\2\2\u00fd")
        buf.write(u"\u00fe\7e\2\2\u00fe\62\3\2\2\2\u00ff\u0100\7^\2\2\u0100")
        buf.write(u"\u0101\7u\2\2\u0101\u0102\7g\2\2\u0102\u0103\7e\2\2\u0103")
        buf.write(u"\64\3\2\2\2\u0104\u0105\7^\2\2\u0105\u0106\7e\2\2\u0106")
        buf.write(u"\u0107\7q\2\2\u0107\u0108\7v\2\2\u0108\66\3\2\2\2\u0109")
        buf.write(u"\u010a\7^\2\2\u010a\u010b\7c\2\2\u010b\u010c\7t\2\2\u010c")
        buf.write(u"\u010d\7e\2\2\u010d\u010e\7u\2\2\u010e\u010f\7k\2\2\u010f")
        buf.write(u"\u0110\7p\2\2\u01108\3\2\2\2\u0111\u0112\7^\2\2\u0112")
        buf.write(u"\u0113\7c\2\2\u0113\u0114\7t\2\2\u0114\u0115\7e\2\2\u0115")
        buf.write(u"\u0116\7e\2\2\u0116\u0117\7q\2\2\u0117\u0118\7u\2\2\u0118")
        buf.write(u":\3\2\2\2\u0119\u011a\7^\2\2\u011a\u011b\7c\2\2\u011b")
        buf.write(u"\u011c\7t\2\2\u011c\u011d\7e\2\2\u011d\u011e\7v\2\2\u011e")
        buf.write(u"\u011f\7c\2\2\u011f\u0120\7p\2\2\u0120<\3\2\2\2\u0121")
        buf.write(u"\u0122\7^\2\2\u0122\u0123\7c\2\2\u0123\u0124\7t\2\2\u0124")
        buf.write(u"\u0125\7e\2\2\u0125\u0126\7e\2\2\u0126\u0127\7u\2\2\u0127")
        buf.write(u"\u0128\7e\2\2\u0128>\3\2\2\2\u0129\u012a\7^\2\2\u012a")
        buf.write(u"\u012b\7c\2\2\u012b\u012c\7t\2\2\u012c\u012d\7e\2\2\u012d")
        buf.write(u"\u012e\7u\2\2\u012e\u012f\7g\2\2\u012f\u0130\7e\2\2\u0130")
        buf.write(u"@\3\2\2\2\u0131\u0132\7^\2\2\u0132\u0133\7c\2\2\u0133")
        buf.write(u"\u0134\7t\2\2\u0134\u0135\7e\2\2\u0135\u0136\7e\2\2\u0136")
        buf.write(u"\u0137\7q\2\2\u0137\u0138\7v\2\2\u0138B\3\2\2\2\u0139")
        buf.write(u"\u013a\7^\2\2\u013a\u013b\7u\2\2\u013b\u013c\7k\2\2\u013c")
        buf.write(u"\u013d\7p\2\2\u013d\u013e\7j\2\2\u013eD\3\2\2\2\u013f")
        buf.write(u"\u0140\7^\2\2\u0140\u0141\7e\2\2\u0141\u0142\7q\2\2\u0142")
        buf.write(u"\u0143\7u\2\2\u0143\u0144\7j\2\2\u0144F\3\2\2\2\u0145")
        buf.write(u"\u0146\7^\2\2\u0146\u0147\7v\2\2\u0147\u0148\7c\2\2\u0148")
        buf.write(u"\u0149\7p\2\2\u0149\u014a\7j\2\2\u014aH\3\2\2\2\u014b")
        buf.write(u"\u014c\7^\2\2\u014c\u014d\7c\2\2\u014d\u014e\7t\2\2\u014e")
        buf.write(u"\u014f\7u\2\2\u014f\u0150\7k\2\2\u0150\u0151\7p\2\2\u0151")
        buf.write(u"\u0152\7j\2\2\u0152J\3\2\2\2\u0153\u0154\7^\2\2\u0154")
        buf.write(u"\u0155\7c\2\2\u0155\u0156\7t\2\2\u0156\u0157\7e\2\2\u0157")
        buf.write(u"\u0158\7q\2\2\u0158\u0159\7u\2\2\u0159\u015a\7j\2\2\u015a")
        buf.write(u"L\3\2\2\2\u015b\u015c\7^\2\2\u015c\u015d\7c\2\2\u015d")
        buf.write(u"\u015e\7t\2\2\u015e\u015f\7v\2\2\u015f\u0160\7c\2\2\u0160")
        buf.write(u"\u0161\7p\2\2\u0161\u0162\7j\2\2\u0162N\3\2\2\2\u0163")
        buf.write(u"\u0164\7^\2\2\u0164\u0165\7u\2\2\u0165\u0166\7s\2\2\u0166")
        buf.write(u"\u0167\7t\2\2\u0167\u0168\7v\2\2\u0168P\3\2\2\2\u0169")
        buf.write(u"\u016a\7^\2\2\u016a\u016b\7v\2\2\u016b\u016c\7k\2\2\u016c")
        buf.write(u"\u016d\7o\2\2\u016d\u016e\7g\2\2\u016e\u016f\7u\2\2\u016f")
        buf.write(u"R\3\2\2\2\u0170\u0171\7^\2\2\u0171\u0172\7e\2\2\u0172")
        buf.write(u"\u0173\7f\2\2\u0173\u0174\7q\2\2\u0174\u0175\7v\2\2\u0175")
        buf.write(u"T\3\2\2\2\u0176\u0177\7^\2\2\u0177\u0178\7f\2\2\u0178")
        buf.write(u"\u0179\7k\2\2\u0179\u017a\7x\2\2\u017aV\3\2\2\2\u017b")
        buf.write(u"\u017c\7^\2\2\u017c\u017d\7h\2\2\u017d\u017e\7t\2\2\u017e")
        buf.write(u"\u017f\7c\2\2\u017f\u0180\7e\2\2\u0180X\3\2\2\2\u0181")
        buf.write(u"\u0182\7a\2\2\u0182Z\3\2\2\2\u0183\u0184\7`\2\2\u0184")
        buf.write(u"\\\3\2\2\2\u0185\u0186\t\2\2\2\u0186^\3\2\2\2\u0187\u018b")
        buf.write(u"\7f\2\2\u0188\u018a\5]/\2\u0189\u0188\3\2\2\2\u018a\u018d")
        buf.write(u"\3\2\2\2\u018b\u018c\3\2\2\2\u018b\u0189\3\2\2\2\u018c")
        buf.write(u"\u0195\3\2\2\2\u018d\u018b\3\2\2\2\u018e\u0196\t\3\2")
        buf.write(u"\2\u018f\u0191\7^\2\2\u0190\u0192\t\3\2\2\u0191\u0190")
        buf.write(u"\3\2\2\2\u0192\u0193\3\2\2\2\u0193\u0191\3\2\2\2\u0193")
        buf.write(u"\u0194\3\2\2\2\u0194\u0196\3\2\2\2\u0195\u018e\3\2\2")
        buf.write(u"\2\u0195\u018f\3\2\2\2\u0196`\3\2\2\2\u0197\u0198\t\3")
        buf.write(u"\2\2\u0198b\3\2\2\2\u0199\u019a\t\4\2\2\u019ad\3\2\2")
        buf.write(u"\2\u019b\u019d\5c\62\2\u019c\u019b\3\2\2\2\u019d\u019e")
        buf.write(u"\3\2\2\2\u019e\u019c\3\2\2\2\u019e\u019f\3\2\2\2\u019f")
        buf.write(u"\u01a7\3\2\2\2\u01a0\u01a1\7.\2\2\u01a1\u01a2\5c\62\2")
        buf.write(u"\u01a2\u01a3\5c\62\2\u01a3\u01a4\5c\62\2\u01a4\u01a6")
        buf.write(u"\3\2\2\2\u01a5\u01a0\3\2\2\2\u01a6\u01a9\3\2\2\2\u01a7")
        buf.write(u"\u01a5\3\2\2\2\u01a7\u01a8\3\2\2\2\u01a8\u01c1\3\2\2")
        buf.write(u"\2\u01a9\u01a7\3\2\2\2\u01aa\u01ac\5c\62\2\u01ab\u01aa")
        buf.write(u"\3\2\2\2\u01ac\u01af\3\2\2\2\u01ad\u01ab\3\2\2\2\u01ad")
        buf.write(u"\u01ae\3\2\2\2\u01ae\u01b7\3\2\2\2\u01af\u01ad\3\2\2")
        buf.write(u"\2\u01b0\u01b1\7.\2\2\u01b1\u01b2\5c\62\2\u01b2\u01b3")
        buf.write(u"\5c\62\2\u01b3\u01b4\5c\62\2\u01b4\u01b6\3\2\2\2\u01b5")
        buf.write(u"\u01b0\3\2\2\2\u01b6\u01b9\3\2\2\2\u01b7\u01b5\3\2\2")
        buf.write(u"\2\u01b7\u01b8\3\2\2\2\u01b8\u01ba\3\2\2\2\u01b9\u01b7")
        buf.write(u"\3\2\2\2\u01ba\u01bc\7\60\2\2\u01bb\u01bd\5c\62\2\u01bc")
        buf.write(u"\u01bb\3\2\2\2\u01bd\u01be\3\2\2\2\u01be\u01bc\3\2\2")
        buf.write(u"\2\u01be\u01bf\3\2\2\2\u01bf\u01c1\3\2\2\2\u01c0\u019c")
        buf.write(u"\3\2\2\2\u01c0\u01ad\3\2\2\2\u01c1f\3\2\2\2\u01c2\u01c3")
        buf.write(u"\7?\2\2\u01c3h\3\2\2\2\u01c4\u01c5\7>\2\2\u01c5j\3\2")
        buf.write(u"\2\2\u01c6\u01c7\7^\2\2\u01c7\u01c8\7n\2\2\u01c8\u01c9")
        buf.write(u"\7g\2\2\u01c9\u01ca\7s\2\2\u01cal\3\2\2\2\u01cb\u01cc")
        buf.write(u"\7@\2\2\u01ccn\3\2\2\2\u01cd\u01ce\7^\2\2\u01ce\u01cf")
        buf.write(u"\7i\2\2\u01cf\u01d0\7g\2\2\u01d0\u01d1\7s\2\2\u01d1p")
        buf.write(u"\3\2\2\2\u01d2\u01d3\7#\2\2\u01d3r\3\2\2\2\u01d4\u01d6")
        buf.write(u"\7^\2\2\u01d5\u01d7\t\3\2\2\u01d6\u01d5\3\2\2\2\u01d7")
        buf.write(u"\u01d8\3\2\2\2\u01d8\u01d6\3\2\2\2\u01d8\u01d9\3\2\2")
        buf.write(u"\2\u01d9t\3\2\2\2\17\2z\u00d0\u018b\u0193\u0195\u019e")
        buf.write(u"\u01a7\u01ad\u01b7\u01be\u01c0\u01d8\3\b\2\2")
        return buf.getvalue()


class PSLexer(Lexer):

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]


    T__0 = 1
    WS = 2
    ADD = 3
    SUB = 4
    MUL = 5
    DIV = 6
    L_PAREN = 7
    R_PAREN = 8
    L_BRACE = 9
    R_BRACE = 10
    L_BRACKET = 11
    R_BRACKET = 12
    BAR = 13
    FUNC_LIM = 14
    LIM_APPROACH_SYM = 15
    FUNC_INT = 16
    FUNC_SUM = 17
    FUNC_PROD = 18
    FUNC_LOG = 19
    FUNC_LN = 20
    FUNC_SIN = 21
    FUNC_COS = 22
    FUNC_TAN = 23
    FUNC_CSC = 24
    FUNC_SEC = 25
    FUNC_COT = 26
    FUNC_ARCSIN = 27
    FUNC_ARCCOS = 28
    FUNC_ARCTAN = 29
    FUNC_ARCCSC = 30
    FUNC_ARCSEC = 31
    FUNC_ARCCOT = 32
    FUNC_SINH = 33
    FUNC_COSH = 34
    FUNC_TANH = 35
    FUNC_ARSINH = 36
    FUNC_ARCOSH = 37
    FUNC_ARTANH = 38
    FUNC_SQRT = 39
    CMD_TIMES = 40
    CMD_CDOT = 41
    CMD_DIV = 42
    CMD_FRAC = 43
    UNDERSCORE = 44
    CARET = 45
    DIFFERENTIAL = 46
    LETTER = 47
    NUMBER = 48
    EQUAL = 49
    LT = 50
    LTE = 51
    GT = 52
    GTE = 53
    BANG = 54
    SYMBOL = 55

    modeNames = [ u"DEFAULT_MODE" ]

    literalNames = [ u"<INVALID>",
            u"','", u"'+'", u"'-'", u"'*'", u"'/'", u"'('", u"')'", u"'{'", 
            u"'}'", u"'['", u"']'", u"'|'", u"'\\lim'", u"'\\int'", u"'\\sum'", 
            u"'\\prod'", u"'\\log'", u"'\\ln'", u"'\\sin'", u"'\\cos'", 
            u"'\\tan'", u"'\\csc'", u"'\\sec'", u"'\\cot'", u"'\\arcsin'", 
            u"'\\arccos'", u"'\\arctan'", u"'\\arccsc'", u"'\\arcsec'", 
            u"'\\arccot'", u"'\\sinh'", u"'\\cosh'", u"'\\tanh'", u"'\\arsinh'", 
            u"'\\arcosh'", u"'\\artanh'", u"'\\sqrt'", u"'\\times'", u"'\\cdot'", 
            u"'\\div'", u"'\\frac'", u"'_'", u"'^'", u"'='", u"'<'", u"'\\leq'", 
            u"'>'", u"'\\geq'", u"'!'" ]

    symbolicNames = [ u"<INVALID>",
            u"WS", u"ADD", u"SUB", u"MUL", u"DIV", u"L_PAREN", u"R_PAREN", 
            u"L_BRACE", u"R_BRACE", u"L_BRACKET", u"R_BRACKET", u"BAR", 
            u"FUNC_LIM", u"LIM_APPROACH_SYM", u"FUNC_INT", u"FUNC_SUM", 
            u"FUNC_PROD", u"FUNC_LOG", u"FUNC_LN", u"FUNC_SIN", u"FUNC_COS", 
            u"FUNC_TAN", u"FUNC_CSC", u"FUNC_SEC", u"FUNC_COT", u"FUNC_ARCSIN", 
            u"FUNC_ARCCOS", u"FUNC_ARCTAN", u"FUNC_ARCCSC", u"FUNC_ARCSEC", 
            u"FUNC_ARCCOT", u"FUNC_SINH", u"FUNC_COSH", u"FUNC_TANH", u"FUNC_ARSINH", 
            u"FUNC_ARCOSH", u"FUNC_ARTANH", u"FUNC_SQRT", u"CMD_TIMES", 
            u"CMD_CDOT", u"CMD_DIV", u"CMD_FRAC", u"UNDERSCORE", u"CARET", 
            u"DIFFERENTIAL", u"LETTER", u"NUMBER", u"EQUAL", u"LT", u"LTE", 
            u"GT", u"GTE", u"BANG", u"SYMBOL" ]

    ruleNames = [ u"T__0", u"WS", u"ADD", u"SUB", u"MUL", u"DIV", u"L_PAREN", 
                  u"R_PAREN", u"L_BRACE", u"R_BRACE", u"L_BRACKET", u"R_BRACKET", 
                  u"BAR", u"FUNC_LIM", u"LIM_APPROACH_SYM", u"FUNC_INT", 
                  u"FUNC_SUM", u"FUNC_PROD", u"FUNC_LOG", u"FUNC_LN", u"FUNC_SIN", 
                  u"FUNC_COS", u"FUNC_TAN", u"FUNC_CSC", u"FUNC_SEC", u"FUNC_COT", 
                  u"FUNC_ARCSIN", u"FUNC_ARCCOS", u"FUNC_ARCTAN", u"FUNC_ARCCSC", 
                  u"FUNC_ARCSEC", u"FUNC_ARCCOT", u"FUNC_SINH", u"FUNC_COSH", 
                  u"FUNC_TANH", u"FUNC_ARSINH", u"FUNC_ARCOSH", u"FUNC_ARTANH", 
                  u"FUNC_SQRT", u"CMD_TIMES", u"CMD_CDOT", u"CMD_DIV", u"CMD_FRAC", 
                  u"UNDERSCORE", u"CARET", u"WS_CHAR", u"DIFFERENTIAL", 
                  u"LETTER", u"DIGIT", u"NUMBER", u"EQUAL", u"LT", u"LTE", 
                  u"GT", u"GTE", u"BANG", u"SYMBOL" ]

    grammarFileName = u"PS.g4"

    def __init__(self, input=None):
        super(PSLexer, self).__init__(input)
        self.checkVersion("4.5.1")
        self._interp = LexerATNSimulator(self, self.atn, self.decisionsToDFA, PredictionContextCache())
        self._actions = None
        self._predicates = None


